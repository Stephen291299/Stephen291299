package com.zoho.TaskManagement;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.time.LocalDate;

public class EmployeeDatabaseWorks {
	public void taskTrackerAdd(int task_id, int status_id, String project_name,
			String comment, int employee_id) {
		LocalDate date = LocalDate.now();
		String query = "INSERT INTO taskTracker (project_name,task_id,status_id,date,comment,"
				+ "employee_id) VALUES (?,?,?,?,?,?)";
		try (PreparedStatement pr = DatabaseConnection.getConnection()
				.prepareStatement(query);) {
			pr.setString(1, project_name);
			pr.setInt(2, task_id);
			pr.setInt(3, status_id);
			pr.setDate(4, Date.valueOf(date));
			pr.setString(5, comment);
			pr.setInt(6, employee_id);
			pr.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void taskStatusUpdate(int task_id,int status_id)
	{
		String query = "update task_details set status_id="+status_id+"where task_id="+task_id+";";
		try (PreparedStatement pr = DatabaseConnection.getConnection()
				.prepareStatement(query);) {
			pr.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
