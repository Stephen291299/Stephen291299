package com.zoho.TaskManagement;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.Scanner;

public class EmployeePage {

	static BufferedReader scan = new BufferedReader(new InputStreamReader(System.in));
	static EmployeeView ev=new EmployeeView();
	static EmployeeDatabaseWorks ed = new EmployeeDatabaseWorks();

	public void mainMenu(String userName) {
		try {
			int employeeId = ev.getEmployeeId(userName);
			Scanner sc = new Scanner(System.in);
			int choice;
			do {
				System.out.println("_________________________________________________________________________________\n");
				System.out.println("\t\t\t Employee page ");
				System.out.println("__________________________________________________________________________________\n\n");
				System.out.println("\t 1. Assigned Tasks");
				System.out.println("\t 2. Inprogress Tasks");
				System.out.println("\t 3. Project Tasks");
				System.out.println("\t 4. Exit");
				System.out.println("\n\n\tEnter Your Choice : ");
				choice = sc.nextInt();
				System.out.println("__________________________________________________________________________________");

				switch (Choices.getChoice(choice)) {
				case ASSIGNED_TASKS:
					taskShow(employeeId);
					break;
				case INPROCESS_TASKS:
					inprogressTasks(employeeId);
					break;
				case PROJECT_TASKS:
					projectTasks(employeeId);
					break;
				case EXIT:
					System.out.println("Are You Sure (y/n) : ");
					if (sc.next().equalsIgnoreCase("y")) {
						choice = -1;
						scan.close();
						sc.close();
					}
					break;
				default:
					System.out.println("INVALID CHOICE !!!");
					break;
				}
			} while (choice != -1);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void taskShow(int employeeId) {
		try {
			if (ev.showTask(employeeId)) {
				System.out.println("\nAre you ready to get the task (y/n)");
				if (scan.readLine().equalsIgnoreCase("y")) {
					taskStatusModify(employeeId);
				} else {
					System.out.println("Thank you...");
				}
			} else {
				System.out.println("Tasks not Assign..");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void inprogressTasks(int employeeId) {
		try {
			if (ev.showInprogressTask(employeeId)) {
				System.out.println("\n If you want to modify the status (y/n)");
				if (scan.readLine().equalsIgnoreCase("y")) {
					taskStatusModify(employeeId);
				} else {
					System.out.println("Thank you...");
				}
			} else {
				System.out.println("No process tasks..");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void taskStatusModify(int employeeId) {
		try {
			System.out.println("Please enter the task_id:");
			int task_id = Integer.parseInt(scan.readLine());

			if (ev.checkTaskId(task_id)) {
				System.out.println("Please modify the status...");
				ev.showStatus();
				int status_id = Integer.parseInt(scan.readLine());

				System.out.println("Enter the comment");
				String comment = scan.readLine();

				String projectName = ev.getProjectName(task_id);

				ed.taskTrackerAdd(task_id, status_id, projectName, comment,
						employeeId);
				ed.taskStatusUpdate(task_id, status_id);

				System.out.println("Status updated.....");
			} else {
				System.out.println("Enter correct Id...");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void projectTasks(int employee_id) {
		try {
			System.out.println("Enter the project_name:");
			String project_name = scan.readLine();
			boolean flag = ev.checkProject(project_name);

			if (flag)
				ev.projectTaskShow(project_name, employee_id);
			else
				System.out.println("Project not found...");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}

enum Choices {
	ASSIGNED_TASKS(1),INPROCESS_TASKS(2),PROJECT_TASKS(3),EMPLOYEE_INPROCESS(4),EXIT(5), INVALID(6);

	private int value;
	private Choices(int val) {
		this.value = val;
	}

	public static Choices getChoice(int value) {
		for (Choices t : Choices.values()) {
			if (t.value == value) {
				return t;
			}
		}
		return INVALID;
	}
}
