package com.zoho.TaskManagement;

import java.util.Random;

public class PasswordCreate {

	public String createPassword() {
		Random random = new Random();
		char[] password = new char[8];
		String capitalCaseLetters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
		String lowerCaseLetters = "abcdefghijklmnopqrstuvwxyz";
		String specialCharacters = "!@#$";
		String numbers = "1234567890";
		String combinedChars = capitalCaseLetters + lowerCaseLetters
				+ specialCharacters + numbers;

		password[0] = lowerCaseLetters.charAt(random.nextInt(lowerCaseLetters
				.length()));
		password[1] = capitalCaseLetters.charAt(random
				.nextInt(capitalCaseLetters.length()));
		password[2] = specialCharacters.charAt(random.nextInt(specialCharacters
				.length()));
		password[3] = numbers.charAt(random.nextInt(numbers.length()));

		for (int i = 4; i < 8; i++) {
			password[i] = combinedChars.charAt(random.nextInt(combinedChars
					.length()));
		}
		return String.valueOf(password);
	}

	public String createUserName(String userName) {
		userName = userName.replace(" ", " @");

		Random random = new Random();
		char[] name = new char[10];

		String specialCharacters = "@$&";
		String numbers = "1234567890";
		String combinedChars = specialCharacters + numbers;
		name[0] = userName.charAt(0);
		name[1] = userName.charAt(1);
		name[2] = userName.charAt(2);
		name[3] = userName.charAt(3);
		for (int i = 4; i < 9; i++) {
			name[i] = combinedChars.charAt(random.nextInt(combinedChars
					.length()));
		}
		return String.valueOf(name); // change Char array to String with use
										// valueOf method
	}

}
