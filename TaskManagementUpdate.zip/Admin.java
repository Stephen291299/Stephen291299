package com.zoho.TaskManagement;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.Scanner;

public class Admin extends MentorPage{
	public static BufferedReader scan = new BufferedReader(new InputStreamReader(System.in));
	static TaskAdd td=new TaskAdd();
	static Admin aobj=new Admin();
	static AdminDatabaseWorks ad=new AdminDatabaseWorks();
	static MentorDatabaseWorks md=new MentorDatabaseWorks();
	static MentorDatabaseView mv=new MentorDatabaseView();
	
	public void mainMenu(String UserName) {
		try {
			Scanner sc = new Scanner(System.in);
			int choice;
			do {
				System.out.println("_________________________________________________________________________________\n");
				System.out.println("\t\t\t Admin Page ");
				System.out.println("__________________________________________________________________________________\n\n");
				System.out.println("\t 1. Employee Add");
				System.out.println("\t 2. Task Add");
				System.out.println("\t 3. ProjectTaskSeen");
				System.out.println("\t 4. Employee Inprocess work show");
				System.out.println("\t 5. Incomplete Work");
				System.out.println("\t 6. Employee RoleChange");
				System.out.println("\t 7. Employee PersonalDetails");
				System.out.println("\t 8. Exit");
				System.out.println("\n\n\tEnter Your Choice : ");
				choice = sc.nextInt();
				System.out.println("__________________________________________________________________________________");

				switch (Choice.getChoice(choice)) {
				case EMPLOYEE_ADD:
					employeeDetails_Add();
					break;
				case TASK_ADD:
					td.taskAdd(UserName);
					break;
				case PROJECT_TASK_SEEN:
					aobj.projectTasktrack();
					break;
				case EMPLOYEE_INPROCESS:
					aobj.employee_work();
					break;
				case INCOMPLETE_WORK:
					aobj.incompleted_work();
					break;
				case EMPLOYEE_ROLE_CHANGE:
					employeeRoleChange();
					break;
				case EMPLOYEE_PERSIONAL_DETAILS:
					employeePersonalDetails();
					break;
				case EXIT:
					System.out.println("Are You Sure (y/n) : ");
					if (sc.next().equalsIgnoreCase("y"))
					{
						choice = -1;
						scan.close();
						sc.close();
					}
					break;
				default:
					System.out.println("INVALID CHOICE !!!");
					break;
				}
			} while (choice != -1);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void employeeDetails_Add() {
		try {
			System.out.println("Enter Employee Name :");
			String employee_name = scan.readLine();

			System.out.println("Enter Date of Birth (YYYY-MM-DD) :");
			String dob = scan.readLine();

			System.out.println("Enter Gender :");
			String gender = scan.readLine();

			System.out.println("Enter Email Id :");
			String email_id = scan.readLine();

			System.out.println("Enter Phone NO :");
			long phone_no = Long.parseLong(scan.readLine());
			
			System.out.println("Enter Aadhar NO :");
			long Aadhar_no = Long.parseLong(scan.readLine());

			System.out.println("Enter Address :");
			String address = scan.readLine();

			Employee_details emp = new Employee_details(employee_name, dob,
					gender, email_id, phone_no, Aadhar_no, address);
			ad.insertEmployeeDetails(emp);

			loginDetails_Add(Aadhar_no, employee_name);
		} catch (Exception e) {
			//e.printStackTrace();
			System.out.println("Invalid inputs...");
			return ;
		}
	}

	public void loginDetails_Add(long Aadhar_no, String user_name) {
		try {
			System.out.println("\tEnter the Employee Role :");
			new AdminDatabaseWorks().showRole();
			int role_id = Integer.parseInt(scan.readLine());

			System.out.println("Enter UserName: ");
			String userName = scan.readLine();

			String password = new PasswordCreate().createPassword();
			int employee_id = ad
					.getEmployeee_id(Aadhar_no);

			if (ad.insertLoginDetails(userName, password,
					employee_id, role_id))
			{
				System.out.println("Employee Details Added Successfully.....");
				System.out.println("Employee Id is: " + employee_id);
				System.out.println("Employee UserName is: " + userName);
				System.out.println("Employee Password is: " + password);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void employeeRoleChange() {
		try {
			System.out.println("Enter the employee_id");
			int employee_id = Integer.parseInt(scan.readLine());

			if (mv.employee_id_check(employee_id)) {
				System.out.println("\tEnter the Employee Role :");
				ad.showRole();
				int role_id = Integer.parseInt(scan.readLine());

				ad.changeRole(employee_id, role_id);
				System.out.println("Employee role changed...");
			} else {
				System.out.println("Employee not Found...");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
	public void employeePersonalDetails()
	{
		try
		{
			System.out.println("Enter the employee_id:");
			int employee_id=Integer.parseInt(scan.readLine());
	
			if(mv.employee_id_check(employee_id))
			{
				ad.employeePersonalDetails(employee_id);
			}
			else
			{
				System.out.println("Employee not Found...");
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
}

enum Choice {
	EMPLOYEE_ADD(1), TASK_ADD(2), PROJECT_TASK_SEEN(3), EMPLOYEE_INPROCESS(4), INCOMPLETE_WORK(5), 
	EMPLOYEE_ROLE_CHANGE(6),EMPLOYEE_PERSIONAL_DETAILS(7),EXIT(8), INVALID(9);

	private int val;
	private Choice(int val) {
		this.val = val;
	}

	public static Choice getChoice(int value) {
		for (Choice t : Choice.values()) {
			if (t.val == value) {
				return t;
			}
		}
		return INVALID;
	}
}
