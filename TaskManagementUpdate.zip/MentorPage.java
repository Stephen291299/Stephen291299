package com.zoho.TaskManagement;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.Scanner;

public class MentorPage {
	public static BufferedReader scan = new BufferedReader(
			new InputStreamReader(System.in));
	static TaskAdd td=new TaskAdd();
	static AdminDatabaseWorks ad=new AdminDatabaseWorks();
	static MentorDatabaseWorks md=new MentorDatabaseWorks();
	static MentorDatabaseView mv=new MentorDatabaseView();

	public void mainMenu(String userName) {
		try {
			Scanner sc = new Scanner(System.in);
			int choice;
			do {
				System.out.println("_________________________________________________________________________________\n");
				System.out.println("\t\t\t Mentor page ");
				System.out.println("__________________________________________________________________________________\n\n");
				System.out.println("\t 1. Tasks Add");
				System.out.println("\t 2. TaskSeen");
				System.out.println("\t 3. Employee Inprocess Worke show");
				System.out.println("\t 4. Incomplete Work");
				System.out.println("\t 5. Exit");
				System.out.println("\n\n\tEnter Your Choice : ");
				choice = sc.nextInt();
				System.out.println("__________________________________________________________________________________");

				switch (choice) {
				case 1:
					td.taskAdd(userName);
					break;
				case 2:
					projectTasktrack();
					break;
				case 3:
					employee_work();
					break;
				case 4:
					incompleted_work();
					break;
				case 5:
					System.out.println("Are You Sure (y/n) : ");
					if (sc.next().equalsIgnoreCase("y"))
					{
						choice = -1;
						scan.close();
						sc.close();
					}
					break;
				default:
					System.out.println("INVALID CHOICE !!!");
					break;
				}
			} while (choice != -1);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void projectTasktrack() {
		try {
			System.out.println("Enter the project_name:");
			String project_name = scan.readLine();
			boolean bool = mv.checkProject(project_name);

			if (bool)
				mv.projectTaskTrackShow(project_name);
			else
				System.out.println("Project not found...");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	
	public void employee_work()
	{
		try
		{
			System.out.println("Enter the employee_id:");
			int employee_id=Integer.parseInt(scan.readLine());
			
			if(mv.employee_id_check(employee_id))
			{
				mv.showInprogressTask(employee_id);
			}
			else
			{
				System.out.println("Employee not Found...");
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	
	public void incompleted_work()
	{
		try
		{
			System.out.println("Enter project Name: ");
			String project_name=scan.readLine();
			if(mv.checkProject(project_name))
			{
				mv.incompleteWorkShow(project_name);
			}
			else
			{
				System.out.println("Project not found...");
			}
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
}
