package com.zoho.TaskManagement;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.time.LocalDate;

public class MentorDatabaseWorks {

	public int taskAdd(String project_name, String task_name,
			String description, int employeeId, int severity_id, String due_date,int status_id) {
		ResultSet rs = null;
		LocalDate date = LocalDate.now();
		String query = "INSERT INTO task_details (project_name,task_name,task_description,taskAssigner,taskAddDate,"
				+ "severity_id,dueDate,status_id) VALUES (?,?,?,?,?,?,?,?)returning task_id ;";
		try (PreparedStatement pr = DatabaseConnection.getConnection()
				.prepareStatement(query);) {
			pr.setString(1, project_name);
			pr.setString(2, task_name);
			pr.setString(3, description);
			pr.setInt(4, employeeId);
			pr.setDate(5, Date.valueOf(date));
			pr.setInt(6, severity_id);
			pr.setDate(7, Date.valueOf(due_date));
			pr.setInt(8, status_id);
			rs = pr.executeQuery();
			while (rs.next()) {
				int id = rs.getInt(1);
				return id;
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return -1;
	}

	public void addSubTask(int task_id, String subTask, String description) {
		String query = "INSERT INTO subTask (mainTask_id,subTaskName,description) VALUES "
				+ "(?,?,?);";
		try (PreparedStatement pr = DatabaseConnection.getConnection()
				.prepareStatement(query);) {
			pr.setInt(1, task_id);
			pr.setString(2, subTask);
			pr.setString(3, description);
			pr.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void tasktoUser(int task_id, int employee_id) {
		LocalDate date = LocalDate.now();
		String query = "INSERT INTO tasktoUser (task_id,employee_id,employeeAddDate) VALUES "
				+ "(?,?,?);";
		try (PreparedStatement pr = DatabaseConnection.getConnection()
				.prepareStatement(query);) {
			pr.setInt(1, task_id);
			pr.setInt(2, employee_id);
			pr.setDate(3, Date.valueOf(date));
			pr.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void taskStatusUpdate(int task_id,int status_id)
	{
		String query = "update task_details set status_id="+status_id+"where task_id="+task_id+";";
		try (PreparedStatement pr = DatabaseConnection.getConnection()
				.prepareStatement(query);) {
			pr.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
	public void taskTrackerAdd(int task_id, int status_id, String project_name,
			String comment, int employee_id) {
		LocalDate date = LocalDate.now();
		String query = "INSERT INTO taskTracker (project_name,task_id,status_id,date,comment,"
				+ "employee_id) VALUES (?,?,?,?,?,?)";
		try (PreparedStatement pr = DatabaseConnection.getConnection()
				.prepareStatement(query);) {
			pr.setString(1, project_name);
			pr.setInt(2, task_id);
			pr.setInt(3, status_id);
			pr.setDate(4, Date.valueOf(date));
			pr.setString(5, comment);
			pr.setInt(6, employee_id);
			pr.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	}
