package com.zoho.TaskManagement;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

public class AdminDatabaseWorks {

	public int logCheck(String user, String pass) {
		
		String query = "SELECT role_id FROM Login where user_name ='" +user+ "'and password='" + pass+ "';";
		try (PreparedStatement pr = DatabaseConnection.getConnection()
				.prepareStatement(query);ResultSet rs=pr.executeQuery();) {
			int role_id;
			while (rs.next()) {
				role_id = rs.getInt("role_id");
				return role_id;
			}
		} catch (SQLException e) { 
			e.printStackTrace();
		}
		return -1;
	}

	public void insertEmployeeDetails(Employee_details emp) {
		String query = "INSERT INTO Employee_details (employee_name,dob,gender,gmail,phoneNumber,aadharNumber,address) VALUES"
				+ "(?,?,?,?,?,?,?);";
		try (PreparedStatement pr = DatabaseConnection.getConnection()
				.prepareStatement(query);) {
			pr.setString(1, emp.getEmployee_name());
			pr.setDate(2, java.sql.Date.valueOf(emp.getDob()));
			pr.setString(3, emp.getGender());
			pr.setString(4, emp.getGmail());
			pr.setLong(5, emp.getPhoneNumber());
			pr.setLong(6, emp.getAadharNumber());
			pr.setString(7, emp.getAddress());
			pr.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void showRole() {

		String query = "SELECT * FROM Role;";
		try (PreparedStatement pr = DatabaseConnection.getConnection()
				.prepareStatement(query); ResultSet rs = pr.executeQuery();) {
			while (rs.next())
				System.out.println(rs.getString(2) + "   : Press -> "
						+ rs.getInt(1));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public int getEmployeee_id(long aadhar_no) {
		int Employee_id;
		String query = "SELECT  employee_id from Employee_details where aadharNumber="
				+ aadhar_no + ";";
		try (PreparedStatement pr = DatabaseConnection.getConnection()
				.prepareStatement(query); ResultSet rs = pr.executeQuery();) {
			while (rs.next()) {
				Employee_id = rs.getInt(1);
				return Employee_id;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return -1;
	}

	public boolean insertLoginDetails(String user_name, String password,
			int employee_id, int role_id) {
		String query = "INSERT INTO login (user_name,password,employee_id,role_id) VALUES (?,?,?,?);";
		try(PreparedStatement pr =  DatabaseConnection.getConnection().prepareStatement(query);) {
			pr.setString(1, user_name);
			pr.setString(2, password);
			pr.setInt(3, employee_id);
			pr.setInt(4, role_id);
			pr.executeUpdate();
			return true;
		} catch (Exception e) {
			e.printStackTrace();
		} 
		return false;
	}

	public void changeRole(int employee_id, int role_id) {
		String query = "update login  set role_id =" + role_id
				+ " where employee_id=" + employee_id + ";";
		try(PreparedStatement pr = DatabaseConnection.getConnection().prepareStatement(query);) {
			pr.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} 
	}

	

	public void employeePersonalDetails(int employee_id)
	{
		ArrayList<Employee_details> al=new ArrayList<>();
		SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");
		boolean flag=false;
		String query="select employee_details.employee_id,employee_details.employee_name,employee_details.dob,"
				+ "employee_details.phoneNumber,employee_details.gmail,employee_details.aadharNumber,"
				+ "employee_details.address,employee_details.gender,Role.role from employee_details inner join login on "
				+ "employee_details.employee_id=login.employee_id inner join role on role.role_id=login.role_id "
				+ "where employee_details.employee_id="+employee_id+";";
		
		try (PreparedStatement pr = DatabaseConnection.getConnection()
				.prepareStatement(query); ResultSet rs = pr.executeQuery();) {
			while (rs.next()) {
				flag=true;
				Employee_details emp=new Employee_details();
				emp.setEmployee_id(rs.getInt(1));
				emp.setEmployee_name(rs.getString(2));
				Date date=(rs.getDate(3));
				String strDate = formatter.format(date);  
				emp.setDob(strDate);
				emp.setPhoneNumber(rs.getLong(4));
				emp.setGmail(rs.getString(5));
				emp.setAadharNumber(rs.getLong(6));
				emp.setAddress(rs.getString(7));
				emp.setGender(rs.getString(8));
				String role=rs.getString(9);
				//System.out.println("Employee role:"+ role);
				al.add(emp);
			}	
			if(flag)
			{
				System.out.println(al);
			}
			else 
				System.out.println("Employee_details not found....");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
