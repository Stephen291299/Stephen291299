package com.zoho.TaskManagement;

import java.io.BufferedReader;
import java.io.InputStreamReader;

public class TaskAdd {
	static MentorDatabaseView mv=new MentorDatabaseView();
	static MentorDatabaseWorks md=new MentorDatabaseWorks();
	private static BufferedReader scan = new BufferedReader(new InputStreamReader(System.in));
	public void taskAdd(String UserName)
	{
		try {
			System.out.println("Enter Project_Name :");
			String project_name = scan.readLine();
			
			System.out.println("Enter Task_name :");
			String task_name = scan.readLine();
			
			System.out.println("Enter Task Description :");
			String description = scan.readLine();
			
			System.out.println("Enter Due Date (YYYY-MM-DD):");
			String due_date = scan.readLine();
			
			System.out.println("\tEnter Severity Type:\n");
			mv.showSeverity();
			int severity_id=Integer.parseInt(scan.readLine());
			
			System.out.println("\tPlease enter the status to task...");
			mv.showStatus();
			int status_id=Integer.parseInt(scan.readLine());
			
			int employeeId=mv.getEmployeeId(UserName);
			int task_id=md.taskAdd(project_name,task_name,description,employeeId,severity_id,
					due_date,status_id);
			
			subTaskAdd(task_id);
			tasktoUser(task_id);
			taskTracker(task_id,employeeId,project_name,status_id);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	

	public void subTaskAdd(int task_id)
	{
		int choice;
		try
		{
			do{
				System.out.println("If you want add any subTask for the task...please press : 1\n  else press 2...");
				choice =Integer.parseInt(scan.readLine());
				if(choice==1)
				{
					System.out.println("Enter the subtaskName:");
					String subTask=scan.readLine();
					System.out.println("Enter the subTaskDescription:");
					String description=scan.readLine();
					
					md.addSubTask(task_id,subTask,description);
				}
				else 
					choice=-1;
				
			}while(choice!=-1);
		}
		catch(Exception e)
		{
			System.out.println();
			//e.printStackTrace();
		}
	}
	
	
	public void tasktoUser(int task_id)
	{
		int choice;
		try
		{
			do{
				System.out.println("Press 1 to add  employee to the task...else press 2");
				choice=Integer.parseInt(scan.readLine());
				
				if(choice==1)
				{
					System.out.println("Enter the employee_id to assign the work...");
					int Employee_id=Integer.parseInt(scan.readLine());
					
					if(mv.employee_id_check(Employee_id))
						md.tasktoUser(task_id,Employee_id);
					else
						System.out.println("Employee does not found...");
				}
				else 
					choice=-1;
			}while(choice !=-1);
			
		}
		catch(Exception e)
		{
			System.out.println();
			//e.printStackTrace();
		}
	}
	
	
	public void taskTracker(int task_id,int employee_id,String projrctName,int status_id)
	{
		try
		{
			System.out.println("add any comment for the task ... ");
			String comment=scan.readLine();
			
			md.taskTrackerAdd(task_id,status_id,projrctName,comment,employee_id);
			
			System.out.println("Task Added Sucessfully...");
		}
		catch(Exception e)
		{
			
		}
	}
	
	
}
