package com.zoho.TaskManagement;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.SQLException;

public class TaskMain {
	public static BufferedReader scan = new BufferedReader(
			new InputStreamReader(System.in));
	static Admin aobj=new Admin();
	static AdminDatabaseWorks ad=new AdminDatabaseWorks();
	static MentorPage mp=new MentorPage();
	static EmployeePage ep=new EmployeePage();
	
	public static void main(String[] args) {
		for (int i = 3; i >= 0; i--) {
			try {
				System.out.println("_________________________________________________________________________________\n");
				System.out.println("\t\t\t Login Page ");
				System.out.println("__________________________________________________________________________________\n\n");
				System.out.println("Enter your userName:");
				String userName = scan.readLine();
				System.out.println("Enter your password:");
				String password = scan.readLine();
				int id =ad.logCheck(userName, password);
				if (id == 1) {
					aobj.mainMenu(userName);
					System.out.println("Thank You..");
					break;
				} else if (id == 2) {
					mp.mainMenu(userName);
					System.out.println("Thank You..");
					break;
				} else if (id == 3) {
					ep.mainMenu(userName);
					System.out.println("Thank You..");
					break;
				} else {
					System.out.println("Check your Username and password...");
					System.out.println("you have only " + i+ " chances remaining...\nIf you want to continue press any characters"
							+ " else press 'n' to exit...");
					if (scan.readLine().equalsIgnoreCase("n"))
					{
						System.out.println("Thank you..");
						break;
					}
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	public void finalize() {
		try {
			if (scan != null) {
				scan.close();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
