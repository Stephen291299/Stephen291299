package com.zoho.TaskManagement;

import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class MentorDatabaseView {
	public void showSeverity() {
		String query = "SELECT * FROM severity;";
		try (PreparedStatement pr = DatabaseConnection.getConnection()
				.prepareStatement(query); ResultSet rs = pr.executeQuery();) {

			while (rs.next())
				System.out.println(rs.getString(2) + " Press ----> "
						+ rs.getInt(1));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public int getEmployeeId(String user) {
		int Employee_id;
		String query = "SELECT  employee_id from login where user_name='"
				+ user + "';";
		try (PreparedStatement pr = DatabaseConnection.getConnection()
				.prepareStatement(query); ResultSet rs = pr.executeQuery();) {
			while (rs.next()) {
				Employee_id = rs.getInt(1);
				return Employee_id;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return -1;
	}
	
	public boolean employee_id_check(int employee_id) {
		String query = "SELECT  employee_id from employee_details where employee_id="
				+ employee_id + ";";
		try (PreparedStatement pr = DatabaseConnection.getConnection()
				.prepareStatement(query); ResultSet rs = pr.executeQuery();) {
			while (rs.next()) {
				return true;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}
	
	public void showStatus() {
		String query = "SELECT * FROM workStatus;";
		try (PreparedStatement pr = DatabaseConnection.getConnection()
				.prepareStatement(query); ResultSet rs = pr.executeQuery();) {
			while (rs.next())
				System.out.println(rs.getString(2) + " :  'Press' ----> "
						+ rs.getInt(1));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public boolean checkProject(String projectName) {
		String query = "SELECT  project_name from task_details where project_name='"
				+ projectName + "';";
		try (PreparedStatement pr = DatabaseConnection.getConnection()
				.prepareStatement(query); ResultSet rs = pr.executeQuery();) {
			while (rs.next()) {
				return true;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}
	public void projectTaskTrackShow(String project_name) {
		String query = "select task_details.project_name,task_details.task_id,tasktracker.date,"
				+ "tasktracker.employee_id,workstatus.status,task_details.task_name from task_details "
				+ "inner join workstatus on task_details.status_id=workstatus.status_id inner join "
				+ "tasktracker on task_details.task_id=tasktracker.task_id  "
				+ "where task_details.project_name='"+ project_name + "';";
		try (PreparedStatement pr = DatabaseConnection.getConnection()
				.prepareStatement(query); ResultSet rs = pr.executeQuery();) {
			while (rs.next()) {
				System.out.printf(
						"Project Name=%s | Task_id=%s | LastModifyDate=%s | Employee_id=%s |"
								+ " Status=%s | task_name=%s ",
						rs.getString(1), rs.getInt(2), rs.getDate(3),
						rs.getInt(4), rs.getString(5), rs.getString(6));
				System.out.println();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
	public void incompleteWorkShow(String project_name) {
		String query = "select tasK_details.project_name,task_details.task_id,task_details.task_name,tasktracker.date ,tasktracker.employee_id "
				+ "from task_details inner join tasktracker on task_details.task_id=tasktracker.task_id "
				+ "where tasktracker.project_name='"
				+ project_name
				+ "' and task_details.status_id=5 ;";
		boolean flag=false;
		try (PreparedStatement pr = DatabaseConnection.getConnection()
				.prepareStatement(query); ResultSet rs = pr.executeQuery();) {
			
			while (rs.next()) {
				flag=true;
				System.out
						.printf("ProjectName=%s | Task_id=%d | Task_Name=%s | ModifyDate=%s | EmployeeId=%s ",
								rs.getString(1), rs.getInt(2), rs.getString(3),
								rs.getDate(4), rs.getInt(5));
				System.out.println();
			}
		
			if(flag){}
			else
				System.out.println("Incomplete work not found...");
				
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public boolean showInprogressTask(int employeeId) {
		String query = "SELECT  task_details.project_name,task_details.task_id,task_details.task_name,"
				+ "task_details.task_description,task_details.duedate,"
				+ "severity.severity_type,workStatus.status from task_details inner join tasktouser on "
				+ "task_details.task_id=tasktouser.task_id "
				+ "inner join severity on severity.severity_id=task_details.severity_id "
				+ "inner join workstatus on workStatus.status_id=task_details.status_id "
				+ "where tasktouser.employee_id="
				+ employeeId
				+ "and task_details.status_id=2;";
		boolean flag=false;
		try (PreparedStatement pr = DatabaseConnection.getConnection()
				.prepareStatement(query); ResultSet rs = pr.executeQuery();) {
			while (rs.next()) {
				flag=true;
				System.out
						.printf("Project Name=%s | Task_id=%s | Task_Name=%s | Task_description=%s | DueDate=%s |"
								+ " SeverityType=%s | Status=%s ",
								rs.getString(1), rs.getInt(2), rs.getString(3),
								rs.getString(4), rs.getDate(5),
								rs.getString(6), rs.getString(7));
				System.out.println();
			}
			if(flag)
				System.out.println();
			else
				System.out.println("Tasks not found...");
		} catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}


}
