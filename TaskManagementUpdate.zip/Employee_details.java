package com.zoho.TaskManagement;

public class Employee_details {
	private int employee_id;
	private String employee_name;
	private String dob;
	private String gender;
	private String gmail;
	private long phoneNumber;
	private long aadharNumber;
	private String address;

	public Employee_details() {
			
	}

	Employee_details(String employee_name, String dob, String gender,
			String gmail, long phoneNumber, long aadharNumber, String address) {
		this.employee_name = employee_name;
		this.dob = dob;
		this.gender = gender;
		this.gmail = gmail;
		this.phoneNumber = phoneNumber;
		this.aadharNumber = aadharNumber;
		this.address = address;
	}

	public int getEmployee_id() {
		return employee_id;
	}

	public String getEmployee_name() {
		return employee_name;
	}

	public String getDob() {
		return dob;
	}

	public String getGender() {
		return gender;
	}

	public String getGmail() {
		return gmail;
	}

	public long getPhoneNumber() {
		return phoneNumber;
	}

	public long getAadharNumber() {
		return aadharNumber;
	}

	public String getAddress() {
		return address;
	}

	public void setEmployee_id(int employee_id) {
		this.employee_id = employee_id;
	}

	public void setEmployee_name(String employee_name) {
		this.employee_name = employee_name;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public void setGmail(String gmail) {
		this.gmail = gmail;
	}

	public void setPhoneNumber(long phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public void setAadharNumber(long aadharNumber) {
		this.aadharNumber = aadharNumber;
	}

	public void setAddress(String address) {
		this.address = address;
	}
	
	public String toString()
	{
		return "Employee_id="+ employee_id +",Employee_name=" + employee_name + ",Dob=" +dob + ",phoneNumber="+phoneNumber
				+ ",Gmail=" + gmail + ",AadharNumber=" + aadharNumber + ",Address=" + address + ",Gender=" + gender  ;
	}
}
